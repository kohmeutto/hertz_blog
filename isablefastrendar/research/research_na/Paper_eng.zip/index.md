+++
title = "Paper_eng"
weight = 3
+++
---

### Algebraic Purification of Operator Residue in Singular Perturbation Systems

Kibeom Kim<sup>1</sup>, Young Jun Yoon<sup>2*</sup>

<sup>1</sup>Independent Researcher, Republic of Korea (kohmeutto@gmail.com)

<sup>2</sup>School of Electronic and Mechanical Engineering, Gyeongkuk National University, Andong, Republic of Korea (yjyoon@gknu.ac.kr)

<sup>*</sup>Correspondence: Young Jun Yoon

Keywords: Algebraic purification, Jacobian non-normality, Discrete commutator error, Local asymmetry indicator, Finite volume method

---

### Abstract

The discretization of nonlinear partial differential equations involving material discontinuities and advection induces Jacobian operator non-normality, causing spectral drift and convergence degradation. Introducing empirical relaxation factors or numerical diffusion for system stabilization alters mathematical consistency. Because anti-symmetric convective components are physically inherent, their unjustified removal deviates the solution trajectory. To address this issue without empirical parameter tuning, this study proposes diagnostic indicators to quantify the advective asymmetry, and based on these indicators, establishes an algebraic purification procedure to validate the structural health of the discrete operator. By defining the residue transformation of the linear operator, the continuous residual is mapped to the discrete space to derive a local indicator based on the discrete commutator error to guide geometric control. Furthermore, a global indicator is extracted to construct an algebraic preconditioner. By integrating these spatial and algebraic indicators, the preconditioned Jacobian is purified by subtracting only the incompressible, purely rotational anti-symmetric residues responsible for spectral drift. Utilizing this purified Jacobian within an inexact Newton method restores the structural health of the discrete operator while maintaining the correct solution trajectory. Verified via the method of manufactured solutions (MMS) in singular perturbation systems, the proposed purification demonstrates condition number stabilization. By correcting the cross-coupling asymmetry via linear algebraic projections, the procedure satisfies the asymptotic quadratic convergence of the finite volume method (FVM) without the addition of artificial numerical viscosity.

---

### 1. Introduction

Nonlinear partial differential equations (PDEs) develop state variable gradients in regions containing boundary layers, shock waves, and material discontinuities. When such systems are linearized via projection into discrete spaces, such as the finite volume method (FVM), the Jacobian operator exhibits structural non-normality due to convective components [1, 2]. The spectrum of a non-normal operator yields a non-orthogonal eigenvector basis, causing transient growth of perturbations even when eigenvalues reside in the stable region of the complex plane [3, 4]. This ill-conditioning reduces the convergence speed of Krylov subspace methods and contributes to the divergence of nonlinear iterative solvers [5, 6, 7]. To suppress discrete commutator errors arising from the effective drift velocity divergence during the discretization of continuous conservation laws into non-uniform meshes, r-adaptive topological mapping techniques are employed [8, 9, 10, 11]. Specifically, adaptive grid generation based on the Graph Laplacian and topological mapping serves to disperse mesh distortion and prevent tangling [12]. However, geometric regularity alone is insufficient to eliminate the intrinsic asymmetry of the Jacobian induced by convective terms, necessitating explicit purification to control spectral distortion.

Therefore, this study proposes an algebraic purification procedure to control convective asymmetry without requiring empirical parameter tuning or additional numerical dissipation. Because anti-symmetric convective components are physically inherent to the governing equations, their unjustified removal introduces approximation errors and deviates the solution trajectory. To address this, the proposed method compresses the advective asymmetry into a symmetric scalar potential space. A residual projection of linear operators is introduced to isolate first-order convective residuals within the Jacobian. Using the isolated residuals, a local indicator is derived to explicitly resolve sharp gradients and guide geometric topological mapping via the Graph Laplacian. Furthermore, a global indicator is extracted from the cross-diagonal component ratio to construct an algebraic preconditioner. This study analytically proves that the global indicator is equivalent to the geometric volume ratio of the discrete FVM domain and the one-dimensional line integral of the drift velocity. Integrating this formulation with the discrete Helmholtz-Hodge decomposition (DHHD), the physical asymmetry is projected onto the Graph Laplacian and preserved as a symmetric gradient field. By integrating these spatial and algebraic indicators, the preconditioned Jacobian is finally purified by algebraically subtracting the incompressible, purely rotational anti-symmetric residues responsible for spectral drift and the search domain of the linear solver is symmetrized [13].

To evaluate the structural health of the discrete operator and the validity of the proposed indicator-driven purification, error evaluation is performed using the method of manufactured solutions (MMS) [14, 15, 16]. It is confirmed that the indicator-based purification algorithm suppresses divergence due to floating-point errors and satisfies the theoretical asymptotic second-order convergence even under conditions of material discontinuity where analytical solutions are absent. By preserving physical information through algebraic projection rather than arbitrary addition of artificial viscosity or parameter tuning, the procedure maintains structural robustness. The remainder of this paper is organized as follows. Section 2 describes the residue mapping of non-normal operators and Fréchet derivative expansion. Section 3 establishes the algebraic purification procedure based on discrete commutator errors and orthogonal projections. Section 4 describes numerical results for one-dimensional and two-dimensional singular perturbation systems.

---

### 2. Residual projection of non-normal operators and Fréchet derivative expansion

This section algebraically analyzes the factors increasing the condition number of the Jacobian matrix in discrete spaces. The residual projection of a linear operator $L$ is defined. Using this projection, the weak form of the first-order advection operator, which contributes to asymmetry, is derived via the Fréchet derivative.

#### 2.1. Algebraic residual projection

To analyze the algebraic characteristics of differential operators, an inner product $\langle\phi,\psi\rangle=\int_{\Omega}\phi^{*}\psi d\Omega$ is defined for state functions $\phi$ and $\psi$ within a complex Hilbert space $\mathcal{H}$. The superscript $*$ denotes the complex conjugate. Preserving the relationship between a differential operator and its formal adjoint during the discretization of PDEs is a prerequisite for ensuring physical conservation laws and numerical stability [17, 18, 19, 20]. When global self-adjointness is not satisfied due to convective terms, the residual projection $\mathcal{R}$ is defined to quantify the difference between an operator $L$ and its formal adjoint $L^\dagger$:

$$
\mathcal{R}(L) \equiv L - L^\dagger
\quad\text{(1)}
$$

The expansion of the weak form in the inner product space is as follows:

$$
\langle \phi, \mathcal{R}(L) \psi \rangle \equiv \langle \phi, (L - L^\dagger) \psi \rangle = \langle \phi, L \psi \rangle - \langle \phi, L^\dagger \psi \rangle
\quad\text{(2)}
$$

The residue operator preserves the additivity and homogeneity of linear operators. For scalar coefficients $\alpha, \beta \in \mathbb{R}$ and operators $A$ and $B$, the following holds:

$$
\mathcal{R}(\alpha A + \beta B) = \alpha \mathcal{R}(A) + \beta \mathcal{R}(B)
\quad\text{(3)}
$$

When a discretized system for PDEs includes convective components, the Jacobian operator exhibits structural non-normality. The spectrum of such a non-normal operator yields a non-orthogonal basis [3, 4], inducing transient growth of perturbations during Newton iterations. Consequently, the residual projection serves as an algebraic diagnostic tool to quantify factors increasing non-normality, providing a mathematical foundation for the indicators used to evaluate the structural health of the discrete operator.

#### 2.2. Separation of convective residuals

The Jacobian $J = \partial F / \partial u$ of the governing conservation equation $F(u) = D(p(u)Du) - q(u) = 0$ is expanded [21, 22, 23]. Here, $D$ denotes an abstract spatial differential operator, and $q(u)$ represents a nonlinear source term depending on the state variable $u$. Given a small perturbation $\delta u$ in the state variable $u$, the Jacobian operator $J$ is identified by linearizing the governing equation $F(u) = 0$ around the state $u$. During this process, the nonlinear diffusion coefficient is expanded via Taylor series as $p(u+\delta u) \approx p(u) + (\partial p/\partial u)\delta u$. By retaining the first-order terms in the expansion of the increment $F(u + \delta u) - F(u)$, the action of $J$ on a perturbation $\delta u$ is derived as follows:

$$
J \delta u = \bigg[ \underbrace{D(p(u) D \cdot)}_{L_2} + \underbrace{D \left( \frac{\partial p}{\partial u} Du \cdot \right)}_{L_1} \underbrace{- \frac{\partial q}{\partial u}}_{L_0} \bigg] \delta u
\quad\text{(4)}
$$

The effective drift velocity $v \equiv (\partial p/\partial u)(Du)$ is defined as the product of the state variable gradient $Du$ and the rate of change in material properties $\partial p/\partial u$. The first-order term transforms into an advection operator $L_1 = D(v \cdot)$ [24, 25]. The residual projection is applied to $J = L_2 + L_1 + L_0$:

$$
\mathcal{R}(J) = \mathcal{R}(L_2) + \mathcal{R}(L_1) + \mathcal{R}(L_0)
\quad\text{(5)}
$$

Each term is evaluated via integration by parts within the space of compactly supported test functions $C_c^\infty(\Omega)$. The zeroth-order term $L_0 = -\partial q/\partial u$ and the second-order term $L_2 = D(pD \cdot)$ possess formal self-adjointness. Their residual projections vanish, yielding $\mathcal{R}(L_0) = 0$ and $\mathcal{R}(L_2) = 0$. Consequently, the non-normality of the Jacobian depends on the first-order advection operator $L_1$. Substituting the formal adjoint $L_1^\dagger = -vD$, derived via integration by parts, formulates the residual projection as $\mathcal{R}(L_1)\psi = (L_1 - L_1^\dagger)\psi = D(v\psi) + v(D\psi)$. Applying the Leibniz rule $D(v\psi) = (Dv)\psi + v(D\psi)$ to the first term expands the equation into the following form:

$$
\mathcal{R}(L_1)\psi = \left[ (Dv)\psi + v(D\psi) \right] + v(D\psi) = (Dv)\psi + 2v(D\psi)
\quad\text{(6)}
$$

Expressing this in the weak form, the convective residual inside the nonlinear Jacobian matrix is identified:

$$
\langle \phi, \mathcal{R}(J)\psi \rangle_\Omega = \langle \phi, \left[ (Dv)\psi + 2v(D\psi) \right] \rangle_\Omega
\quad\text{(7)}
$$

This result indicates that the combination of the effective drift velocity divergence $Dv$ and the homogeneous advection $2vD$ induces the system asymmetry. This derivation provides the mathematical basis for constructing the local and global indicators used to control discrete commutator errors in Section 3.

---

### 3. Discrete commutator error and algebraic purification

This section projects the weak form of the convective residuals derived in Section 2 into a discrete linear algebraic system. Using this projection, an r-adaptive topological mapping is performed, and a symmetric preconditioner is designed to control system asymmetry.

#### 3.1. Local indicator and geometric control

The primary target of discretization is the $(Dv)\psi$ term within the continuous Jacobian residuals, representing the divergence of the effective drift velocity acting on the state function. To control numerical oscillations during point-wise evaluation, the algebraic identity $(Dv)\psi = D(v\psi) - v(D\psi)$ is projected onto the discrete space. 

The total discrete differential summation at node $k$ for the product of the state function $\psi$ and velocity $v$ is defined as $[D(v\psi)]_k = \sum_{j} \hat{D}_{kj} (v_j \psi_j)$. Due to the zero-sum property of the discrete differential operator, $\sum_j \hat{D}_{kj} = 0$ holds. Subtracting the arbitrary constant term $v_k \psi_k \sum_j \hat{D}_{kj} = 0$ from the initial summation yields the relative displacement form $\sum_{j} \hat{D}_{kj} (v_j \psi_j - v_k \psi_k)$. Applying the algebraic identity $v_j \psi_j - v_k \psi_k = (v_j - v_k)\psi_j + v_k(\psi_j - \psi_k)$ to this expression separates the discrete mapping into the following equation:

$$
[D(v\psi)]_k = \sum_{j} (v_j - v_k) \hat{D}_{kj} \psi_j + \sum_{j} v_k \hat{D}_{kj} (\psi_j - \psi_k)
\quad\text{(8)}
$$

Here, the second summation term expands to $\sum_j v_k \hat{D}_{kj} \psi_j - v_k \psi_k \sum_j \hat{D}_{kj}$. Since $\sum_j \hat{D}_{kj} = 0$, the latter term vanishes. This isolates the discrete evaluation of the homogeneous advection term $v(D\psi)$ at node $k$:

$$
[v(D\psi)]_k = \sum_{j} v_k \hat{D}_{kj} \psi_j
\quad\text{(9)}
$$

Consequently, the remaining first summation term represents the pure local discrete projection of $(Dv)\psi$ at node $k$:

$$
[(Dv)\psi]_k = \sum_{j} (v_j - v_k) \hat{D}_{kj} \psi_j
\quad\text{(10)}
$$

To evaluate the total convective residual $(Dv)\psi + 2v(D\psi)$ in the discrete space, the discrete homogeneous advection term $\sum_j 2v_k \hat{D}_{kj} \psi_j$ is added to the discrete projection of $(Dv)\psi$. The resulting total discrete convective residual at node $k$ is expressed as the sum of local directional tensions $T_{kj}$:

$$
[(Dv)\psi + 2v(D\psi)]_k = \sum_{j} \Big( (v_j - v_k) \hat{D}_{kj} \psi_j + 2v_k \hat{D}_{kj} \psi_j \Big) \equiv \sum_{j} T_{kj}
\quad\text{(11)}
$$

Here, the local directional tension $T_{kj}$ acting between node $k$ and its adjacent node $j$ is defined by simplifying the summand:

$$
T_{kj} = (v_j + v_k) \hat{D}_{kj} \psi_j
\quad\text{(12)}
$$

The local indicator $S_{kj}$ between nodes is defined as the arithmetic mean of their absolute values to prevent directional cancellation:

$$
S_{kj} = \frac{1}{2} \left( |T_{kj}| + |T_{jk}| \right)
\quad\text{(13)}
$$

A dimensionless indicator $\bar{S}_{kj} = S_{kj} / \max_{mn}(S_{mn})$, normalized by the maximum tension indicator $\max_{mn}(S_{mn})$ across the discrete domain, where $m$ and $n$ denote all pairs of adjacent nodes, is introduced to construct the weight matrix $W_{kj} = 1.0 + \bar{S}_{kj}$. The addition of the baseline stiffness $1.0$ serves two mathematical purposes.  First, this baseline guarantees the positive definiteness of the Graph Laplacian system. Second, the bounded stiffness limits local deformation, preventing topological inversion. This weight $W_{kj}$ acts as the local stiffness of a spring connecting two adjacent nodes, treating the discrete mesh as a virtual spring network. The equilibrium state, minimizing the total strain energy of the system, is determined by the condition that the sum of tensions acting on each internal node $i$ equals a zero vector:

$$
\sum_{j \in \mathcal{N}(i)} W_{ij} (\mathbf{X}_i - \mathbf{X}_j) = \left( \sum_{j \in \mathcal{N}(i)} W_{ij} \right) \mathbf{X}_i - \sum_{j \in \mathcal{N}(i)} W_{ij} \mathbf{X}_j = \mathbf{0}
\quad\text{(14)}
$$

Here, the sum of weights $\sum_j W_{ij}$ represents the degree of node $i$, defining the diagonal entries $K_{ii}$ of the degree matrix $\hat{K}$. By letting $\hat{W}$ be the global adjacency matrix composed of the weights $W_{ij}$, the assembly of these local equilibrium conditions into a global system yields the pure Graph Laplacian $\hat{L}_{sys}$:

$$
\hat{L}_{sys} = \hat{K} - \hat{W}
\quad\text{(15)}
$$

Since the pure Laplacian $\hat{L}_{sys}$ is a singular matrix possessing a null space, Dirichlet boundary conditions using the fixed boundary coordinate vector $\mathbf{B}_{ref}$ are algebraically imposed to guarantee a unique geometric solution. This modifies the operator into the invertible $\tilde{L}_{sys}$, forming the final algebraic system:

$$
\tilde{L}_{sys} \mathbf{X}_{new} = \mathbf{B}_{ref}
\quad\text{(16)}
$$

Each mapped node volume $\tilde{V}_k$ within the derived coordinate system $\mathbf{X}_{new}$ is recalculated, yielding the dual volume metric $\hat{G}$:

$$
\hat{G} = \text{diag}(\tilde{V}_0, \tilde{V}_1, \dots, \tilde{V}_{N-1})
\quad\text{(17)}
$$

This formulation performs topological mapping by integrating the local indicator, derived from commutator errors, into a weighted Graph Laplacian system. Consequently, nodes concentrate in regions with error gradients, while algebraically preserving the positivity of the Jacobian determinant during discrete time integration [26]. This distribution prevents mesh tangling and maintains geometric regularity, even under singular perturbation conditions.

#### 3.2. Global indicator and algebraic preconditioner

The derived geometric metric matrix $\hat{G}$ and the diagonal normalization matrix $\hat{C}$ are applied to the discrete residual vector $\mathbf{F}(\mathbf{u})$ mapped in the finite-dimensional space $\mathbb{R}^N$, constructing a new system $\tilde{\mathbf{F}}(\mathbf{u}) = \hat{C}\hat{G}\mathbf{F}(\mathbf{u}) = \mathbf{0}$. The first-order Taylor approximation for the discrete state vector perturbation $\mathbf{u} + \delta\mathbf{u}$ expands as follows:

$$
\tilde{\mathbf{F}}(\mathbf{u}+\delta\mathbf{u}) \approx \tilde{\mathbf{F}}(\mathbf{u}) + \left[ \left(\frac{\partial\hat{C}}{\partial\mathbf{u}} \delta\mathbf{u}\right) \hat{G}\mathbf{F}(\mathbf{u}) + \hat{C} \left(\frac{\partial\hat{G}}{\partial\mathbf{u}} \delta\mathbf{u}\right) \mathbf{F}(\mathbf{u}) \right] + \hat{C}\hat{G}\hat{J}\delta\mathbf{u}
\quad\text{(18)}
$$

Here, $\hat{J} = \partial\mathbf{F}/\partial\mathbf{u}$ denotes the primitive Jacobian matrix. As Newton iterations progress and the residual vector $\mathbf{F}(\mathbf{u}) \to \mathbf{0}$, the nonlinear tensor derivative terms involving the rates of change of the diagonal metrics asymptotically vanish. Consequently, the effective Jacobian in the convergence regime is defined as $\tilde{J} = \hat{C}\hat{G}\hat{J}$.

To control the non-normality of $\tilde{J}$ and restore symmetry, a magnitude preservation constraint $|\tilde{J}_{ij}| = |\tilde{J}_{ji}|$ is imposed on the cross-diagonal components. Component-wise expansion requires the following algebraic equality:

$$
c_i |(\hat{G}\hat{J})_{ij}| = c_j |(\hat{G}\hat{J})_{ji}|
\quad\text{(19)}
$$

The diagonal components of the matrix $\hat{C}$ are defined as $c_i = e^{z_i}$ to satisfy the positivity condition. Taking the natural logarithm of both sides yields the algebraic difference $b_{ij}$, defining a global indicator on the edge connecting adjacent nodes $i$ and $j$:

$$
\ln(c_i) - \ln(c_j) = \ln\left( \frac{|(\hat{G}\hat{J})_{ji}|}{|(\hat{G}\hat{J})_{ij}|} \right) \equiv b_{ij}
\quad\text{(20)}
$$

For the substitution variable $z_i = \ln(c_i)$, the above equation is an overdetermined linear system of the form $\hat{S}\mathbf{Z} = \mathbf{b}$. The matrix $\hat{S}$ is the edge-node incidence matrix representing the topological connectivity of the discrete mesh. It functions as a discrete gradient operator with elements of $\{-1, 1, 0\}$ depending on the edge direction. The $z_i$ derived through this represents a global potential field obtained by spatially integrating the irrotational component of the local asymmetry indicators $b_{ij}$ scattered across each edge. After imposing the reference point condition on the Dirichlet boundary nodes, the solution $\mathbf{Z}_{LS}$ is calculated through the least squares method to determine $\hat{C}$. The DHHD applied to analyze the linear system and the analysis of the cancellation efficiency of the asymmetric components are described in Appendix A.

#### 3.3. Equivalence of the global indicator

The indicator $b_{ij}$ represents the local flux imbalance induced by the multidimensional effective drift velocity vector $\mathbf{v}$ and geometric volume ratio within $\hat{J}$. To extract the cross-coupling components, the nonlinear parameters are locally frozen. Under this condition, the continuous local residual $F_i$ for the expression $-p\nabla \psi + \mathbf{v}\psi$ is integrated over the control volume and expands into a surface integral over the boundary $\partial \Omega_i$ of node $i$ by applying the divergence theorem via the FVM [27]:

$$
F_i = \iint_{\partial \Omega_i} (-p \nabla \psi + \mathbf{v} \psi) \cdot \mathbf{n} dA = \sum_{j} \Gamma_{i \to j}
\quad\text{(21)}
$$

When the unit direction vector of the edge is $\mathbf{e}_{ij}$ and the one-dimensional coordinate is $\xi$, the one-dimensional directional derivative $\Gamma_{i \to j}$ for the cross-sectional area $A_{ij}$ is expressed as:

$$
\Gamma_{i \to j} = A_{ij} \left( -p(\xi)\frac{d\psi}{d\xi} + v(\xi)\psi \right)
\quad\text{(22)}
$$

Here, $v(\xi) = \mathbf{v} \cdot \mathbf{e}_{ij}$. Since the source term is absent inside the edge, the one-dimensional local flux density within the parentheses of Eq. (22) holds a constant value with respect to the spatial coordinate $\xi$. To solve this first-order linear ordinary differential equation, both sides are divided by $p(\xi)$ and multiplied by the integrating factor to transform it into an exact differential form. Subsequently, performing a definite integral over the entire edge interval $[\xi_i, \xi_j]$ and substituting the state variables $\psi_i$ and $\psi_j$ at both nodes to eliminate the flux density constant yields the directional flux $\Gamma_{i \to j}$ as follows:

$$
\Gamma_{i \to j} = \frac{A_{ij}}{R_{ij}} \psi_i - \frac{A_{ij}}{R_{ij}} \exp\left(-\int_{\xi_i}^{\xi_j} \frac{v(s)}{p(s)} ds\right) \psi_j
\quad\text{(23)}
$$

The effective geometric resistance $R_{ij}$ is defined as:

$$
R_{ij} \equiv \int_{\xi_i}^{\xi_j} \frac{1}{p(\xi)} \exp\left(-\int_{\xi_i}^\xi \frac{v(s)}{p(s)} ds\right) d\xi
\quad\text{(24)}
$$

According to the numerical flux conservation law in discrete space, the cross-flux at the physical interface shared by two nodes exhibits anti-symmetry, denoted as $\Gamma_{j \to i} = -\Gamma_{i \to j}$. This algebraic constraint ensures that the flux leaving node $i$ is identical to the flux entering node $j$, preserving physical consistency. Under this conservation relationship, the cross-coupling components of the primitive Jacobian matrix $\hat{J}$ are extracted by taking the partial derivative of the discrete residual $F_i$ with respect to the perturbation variable $\psi_j$:

$$
\hat{J}_{ij} = \frac{\partial F_i}{\partial \psi_j} = \frac{\partial \Gamma_{i \to j}}{\partial \psi_j} = -\frac{A_{ij}}{R_{ij}} \exp\left(-\int_{\xi_i}^{\xi_j} \frac{v(s)}{p(s)} ds\right)
\quad\text{(25)}
$$

$$
\hat{J}_{ji} = \frac{\partial F_j}{\partial \psi_i} = \frac{\partial (-\Gamma_{i \to j})}{\partial \psi_i} = -\frac{A_{ij}}{R_{ij}}
\quad\text{(26)}
$$

These extracted components are substituted into the global indicator $b_{ij}$ multiplied by the diagonal metric $\hat{G}$:

$$
b_{ij} \equiv \ln \left( \frac{\tilde{V}_j |\hat{J}_{ji}|}{\tilde{V}_i |\hat{J}_{ij}|} \right)
\quad\text{(27)}
$$

The cross-sectional area $A_{ij}$ and geometric resistance $R_{ij}$ cancel out due to the area symmetry $A_{ij} = A_{ji}$ and the anti-symmetry of the discrete flux. Consequently, the vector $b_{ij}$ reduces to the sum of the geometric volume ratio and the one-dimensional line integral of the drift velocity:

$$
b_{ij} = \ln\left(\frac{\tilde{V}_j}{\tilde{V}_i}\right) + \int_{\xi_i}^{\xi_j} \frac{v(s)}{p(s)} ds \equiv \ln\left(\frac{\tilde{V}_j}{\tilde{V}_i}\right) + \int_i^j \left(\frac{\mathbf{v}}{p}\right) \cdot d\mathbf{l}
\quad\text{(28)}
$$

#### 3.4. Anti-symmetric isolation and final purification

$\tilde{J}$ decomposes into a symmetric component $\tilde{H} = (\tilde{J} + \tilde{J}^T)/2$ and an anti-symmetric component $\tilde{A}_{raw} = (\tilde{J} - \tilde{J}^T)/2$. Nodes assigned with Dirichlet boundary conditions have fixed potentials and do not contribute to the convective asymmetry that induces spectral drift. Modifying these boundary components would compromise the well-posedness of the system. Therefore, to isolate only the anti-symmetric component $\tilde{A}_{int}$ corresponding to the internal domain, the matrix is pre- and post-multiplied by a diagonal projection matrix $\hat{M}_s$, assigning 0 to boundary nodes and 1 to internal nodes:

$$
\tilde{A}_{int} = \hat{M}_s \tilde{A}_{raw} \hat{M}_s
\quad\text{(29)}
$$

To preserve physical conservation laws, the intrinsic asymmetric component $\tilde{A}_{int}$ remains exactly evaluated within the discrete residual vector $\tilde{\mathbf{F}}(\mathbf{u})$ on the right-hand side of the governing equation. However, it is algebraically subtracted from the left-hand side system matrix to formulate the purified Jacobian $\tilde{J}_{pure}$, serving as the search matrix for the linear solver:

$$
\tilde{J}_{pure} = \tilde{J} - \tilde{A}_{int}
\quad\text{(30)}
$$

By evaluating the exact nonlinear residual while using the symmetrized approximate Jacobian $\tilde{J}_{pure}$ as the search direction, this formulation completes the final purification of the Jacobian and satisfies the mathematical definition of an inexact Newton method [28, 29]. When the linearization system $\tilde{J}_{pure} \delta\mathbf{u} = -\tilde{\mathbf{F}}(\mathbf{u})$ reaches the convergence state $\delta\mathbf{u} \to \mathbf{0}$, $\tilde{\mathbf{F}}(\mathbf{u}_{\infty}) = \mathbf{0}$ is achieved, where the subscript $\infty$ denotes the converged asymptotic state. Since the transformation matrices $\hat{C}$ and $\hat{G}$ are non-singular diagonal matrices, the original physical residual $\mathbf{F}(\mathbf{u}_{\infty}) = \mathbf{0}$ identically holds, guaranteeing the consistency of the solution. The analytical proof ensuring convergence, by demonstrating that the spectrum of the formulated preconditioner resides within a bounded complex disk, is detailed in Appendix B.

---

### 4. Numerical validation of indicator-driven purification

To evaluate the structural health of the discrete operator and the validity of the indicator-driven purification, this section employs the method of manufactured solutions (MMS) [30, 31, 32, 33, 34, 35]. Here, MMS serves not merely to quantify truncation errors, but to verify that the algebraic purification correctly restores the structural health of the Jacobian without compromising the intrinsic $\mathcal{O}(\Delta x^2)$ convergence. The proposed algebraic purification involves explicit algebraic control, from the assembly of nonlinear operators to the extraction of anti-symmetric components. Consequently, the algorithm separates the control and linear algebra layers, implementing them directly in a 64-bit double-precision environment and excluding general-purpose automatic differentiation libraries or commercial PDE packages. The specific topological mapping and algebraic projection procedures are as follows.

The grid movement control stage performs r-adaptive grid relocation based on the local indicator $S_{kj}$ derived in Section 3.1. A weighted Graph Laplacian system is constructed by incorporating the geometric characteristics of the regions where errors occur into the weight matrix $\hat{W}$ to derive the topological mapping equations [36, 37]. Auto-snapping is applied to nodes adjacent to material interfaces to prevent the harmonic mean paradox. If a discrete node is located within 50% of the element length from the interface, its coordinates are relocated to the interface position. This alignment isolates the numerical singularity at the evaluation point, preventing accidental error cancellation. These limit conditions allow for an objective evaluation of the algebraic purification under severe discretization gradients.

To control the increase in residuals caused by geometric deformation during the mesh relocation process, an optimal state rollback technique is applied. The norm of the nonlinear residual is calculated at each iteration step, and the geometric coordinates and state variables representing the minimum error are stored. If the error increases after grid movement, the system is restored to the previous state and the topological deformation of the mesh is frozen to induce asymptotic convergence. The assembly of the nonlinear residual $F(u)$ and the Fréchet derivative $\hat{J}$ is based on analytical differentiation rules. Spatial integration utilizes multi-point Gauss-Legendre quadrature in 1D domains and edge-midpoint evaluation in 2D unstructured meshes [27].

The algebraic preconditioning stage constructs a diagonal normalization matrix $\hat{C}$ via the global indicator to compress the system asymmetry, satisfying the adjoint consistency condition of Section 3.2. A mask matrix $\hat{M}_s$, functioning as a projection operator, controls the influence of Dirichlet boundary conditions on the internal operator structure. Using this projection, the internal numerical anti-symmetric component $\tilde{A}_{int}$ is separated from the system asymmetry. Subtracting this component from $\tilde{J}$ completes the final purification, yielding the purified Jacobian $\tilde{J}_{pure}$. A UMFPACK-based direct sparse solver solves the linear system $\tilde{J}_{pure} \delta\mathbf{u} = -\tilde{\mathbf{F}}(\mathbf{u})$. The condition numbers $\text{Cond}(\hat{G}\hat{J})$ and $\text{Cond}(\hat{C}\hat{G}\hat{J})$ presented in the subsequent tables denote the condition numbers of the system before and after the application of the algebraic preconditioner $\hat{C}$ to the geometrically scaled Jacobian. This comparison isolates and demonstrates the pure compression capacity of the proposed algebraic scaling matrix.

#### 4.1. 1D singular perturbation system

A strongly elliptic conservation equation with a state-dependent nonlinear diffusion coefficient $p(u, x)$ is defined on a dimensionless one-dimensional Euclidean domain $\Omega = [0, 1]$:

$$
\frac{d}{dx} \left( p(u, x) \frac{du}{dx} \right) = q(x) \quad \text{in } \Omega
\quad\text{(31)}
$$

The domain is divided into a left medium and a right medium at the interface $x_{int} = 0.2$, imposing a discontinuity on the diffusion coefficient $p(u, x)$. The interface is located at an asymmetric position to eliminate geometric dependence, preventing the accidental cancellation of interpolation errors that occurs when the initial uniform grid aligns with the interface. A diffusion contrast coefficient $\sigma$ is applied to the right medium:

$$
p(u, x) = 
\begin{cases} 
1 + u^2 & \text{if } x \le x_{int} \\
\sigma (1 + u^2) & \text{if } x > x_{int} 
\end{cases}
\quad\text{(32)}
$$

The exact analytical solution $u_{exact}(x)$ for the MMS is constructed as follows, utilizing a sinusoidal wave with a wavenumber $k = 2\pi f$, where $f$ denotes the spatial frequency, as the basis function:

$$
u_{exact}(x) = 
\begin{cases} 
\sin(k x) + C_L x & \text{if } x \le x_{int} \\
\sin(k x) + C_R (x - 1) + u_{end} & \text{if } x > x_{int} 
\end{cases}
\quad\text{(33)}
$$

The first-order coefficients $C_L$ and $C_R$ are constants derived to satisfy the potential continuity $u_L = u_R$ and the nonlinear flux continuity $p_L u_L' = p_R u_R'$ at the interface $x_{int}$, where the subscripts $L$ and $R$ denote the limits as $x \to x_{int}$ from the left and right domains, respectively. The target potential at the right boundary $x=1$ is fixed at $u_{end} = 1.0$. An asymmetric Robin mixed boundary condition, expressed as $\alpha u + \beta p(u,x) du/dx = \gamma$ with $\alpha=2.0$ and $\beta=1.0$, is imposed on this right boundary. This condition degrades the diagonal dominance and diffuses non-normality throughout the system during the assembly of the Jacobian matrix.

##### 4.1.1. Asymptotic convergence ($N$)

<br>

<div style="display: flex; justify-content: space-between; gap: 10px; text-align: center;">
<div style="width: 48%;">
<img src="FIG1a.png" style="width: 100%; height: auto;">
<div style="margin-top: 5px;">(a) Potential $u(x)$</div>
</div>
<div style="width: 48%;">
<img src="FIG1b.png" style="width: 100%; height: auto;">
<div style="margin-top: 5px;">(b) Non-linear Diffusion $p(x,u)$</div>
</div>
</div>
<small>Fig. 1. Finite volume solutions using the proposed r-adapted mesh for the 1D singular perturbation problem across selected resolutions for $N \in \{64, 256, 1024\}$. (a) The potential field $u(x)$ capturing the high-frequency sinusoidal wave at $f=10.0$. (b) The non-linear, discontinuous diffusion coefficient $p(x,u)$ illustrating a diffusion drop of $\sigma=10^{-3}$ at $x_{int}=0.2$.</small>

<br><br>

<div style="text-align: center;">
<img src="FIG2.png" style="width: 48%; height: auto;">
<div style="margin-top: 5px;">(c) Mesh Compression Density $\rho(x)$</div>
</div>
<small>Fig. 2. The geometric mesh compression density $\rho(x)$ for the 1D singular perturbation problem, demonstrating the active concentration of control volumes near regions of high gradients in the high-diffusion zone at $x \le 0.2$. The mesh topology asymptotically transitions to a globally uniform state where $\rho \equiv 1$ for $N \ge 1024$.</small>

<br><br>

<small>Table 1: Relative error statistics and algebraic condition number stabilization for the r-adapted solutions across increasing spatial resolutions $N$ under control parameters of $\sigma=10^{-3}$ and $f=10.0$.</small>
| $N$ | $L_2$ Error | Max Error | Raw Asymmetry | Treated Asym | Cond($\hat{G}\hat{J}$) | Cond($\hat{C}\hat{G}\hat{J}$) | Stabilization |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 32 | 3.4549E-01 | 1.3116E+00 | 5.4299E+00 | 2.7285E-12 | 8.3301E+08 | 7.2358E+06 | 115.1 x |
| 64 | 9.7855E-05 | 5.6426E-04 | 2.3634E+00 | 3.6380E-11 | 2.8506E+09 | 2.8233E+07 | 101.0 x |
| 128 | 3.3071E-06 | 1.5701E-05 | 4.4337E+00 | 5.8208E-11 | 1.1737E+10 | 1.1470E+08 | 102.3 x |
| 256 | 5.2587E-08 | 2.5664E-07 | 8.7207E+00 | 3.2014E-10 | 4.8123E+10 | 4.5707E+08 | 105.3 x |
| 512 | 8.0688E-10 | 3.9522E-09 | 1.7467E+01 | 1.5134E-09 | 1.9457E+11 | 1.8354E+09 | 106.0 x |
| 1024 | 2.6417E-12 | 1.3726E-11 | 4.5867E+01 | 4.0745E-09 | 7.4929E+11 | 5.9766E+09 | 125.4 x |
| 2048 | 4.8565E-14 | 2.2263E-13 | 9.1750E+01 | 1.5134E-08 | 2.9987E+12 | 2.3906E+10 | 125.4 x |
| 4096 | 6.4140E-14 | 2.2971E-13 | 1.8330E+02 | 3.4925E-08 | 1.1981E+13 | 9.5508E+10 | 125.4 x |

<br>

The initial experiment analyzes the discretization order and the condition number control performance of the algebraic purification while increasing the control volume resolution $N$ from 32 to 4096 under the controlled conditions of $\sigma=10^{-3}$ and $f=10.0$. The physical setup and numerical results for this case are illustrated in Fig. 1. In this context, a high-frequency sinusoidal wave is captured in the potential field, as shown in Fig. 1a, and a sharp drop at $x_{int}=0.2$ is observed in the non-linear, discontinuous $p(u, x)$, as depicted in Fig. 1b.

Analyzing the indicators in Table 1, the cell-centered $L_2$ global cumulative error of the FVM measures $3.45 \times 10^{-1}$ for the initial coarse grid at $N=32$, decreasing to $9.78 \times 10^{-5}$ at $N=64$. This characterizes the pre-asymptotic region, securing resolution while passing the Nyquist sampling limit of the high-frequency wave $f=10.0$. Thereafter, the error decreases until $N=1024$. For resolutions $N \ge 2048$, the truncation error reaches the $\mathcal{O}(10^{-14})$ band, representing the limit of double-precision floating-point operations. Here, convergence stagnates, but a stable error is maintained without numerical divergence. 

The raw asymmetry indicator exhibits a linear increasing trend proportional to $\mathcal{O}(\Delta x^{-1})$ by a factor of approximately 2 as the grid resolution increases, reaching $1.83 \times 10^2$ at $N=4096$. As described in Section 2, this results from the increased matrix non-normality as the discrete representation of the first-order advection operator expands for finer grid intervals. Consequently, the condition number of the raw Jacobian $\text{Cond}(J)$ scales as $\mathcal{O}(\Delta x^{-2})$, deepening the algebraic ill-conditioning. In contrast, applying the DHHD-based algebraic projection detailed in Section 3.2 restricts the treated asymmetry to the $\mathcal{O}(10^{-8})$ to $\mathcal{O}(10^{-12})$ band. Consequently, a condition number stabilization ratio of 125.4 is observed even under high-resolution limit conditions, confirming the preservation of linear convergence.

Across coarse and intermediate resolution intervals ($32 \le N \le 512$), the control volume compression density $\rho(x) = \Delta x_{init} / \Delta x$ fluctuates in response to the local wave gradient. This density variation is concentrated within the highly diffusive left medium at $x \le 0.2$, as plotted in Fig. 2. As the grid resolution exceeds $N=1024$, the discretization interval secures a geometric resolution capable of resolving the wave gradient and the interface discontinuity. Consequently, local tension is minimized throughout the domain, and the entire grid network transitions to an asymptotically uniform state.

##### 4.1.2. Algebraic robustness ($\sigma$)

<br>

<small>Table 2: Algebraic robustness indicators and relative error statistics under varying diffusion contrast $\sigma$, demonstrating the suppression of spurious non-normality at material interfaces under control parameters of $N=256$ and $f=10.0$.</small>
| $\sigma$ | $L_2$ Error | Max Error | Raw Asymmetry | Treated Asym | Cond($\hat{G}\hat{J}$) | Cond($\hat{C}\hat{G}\hat{J}$) | Stabilization |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 1.0E-0 | 1.4316E-10 | 6.4210E-10 | 1.7889E+02 | 6.8212E-13 | 3.9305E+05 | 1.5312E+05 | 2.6 x |
| 1.0E-1 | 2.1506E-14 | 4.5769E-14 | 2.0816E+02 | 8.5265E-14 | 4.4487E+05 | 3.2962E+05 | 1.3 x |
| 1.0E-2 | 2.6590E-14 | 5.7926E-14 | 2.1126E+02 | 5.6843E-14 | 3.2104E+06 | 2.4886E+06 | 1.3 x |
| 1.0E-3 | 2.7213E-14 | 5.9369E-14 | 2.1157E+02 | 2.8422E-14 | 3.0958E+07 | 2.4100E+07 | 1.3 x |

<br>

The second scenario evaluates the algebraic distortion and stabilization effects while decreasing $\sigma$ from $1.0$ to $10^{-3}$ under fixed conditions of the wave frequency $f=10.0$ and the grid resolution $N=256$, as presented in Table 2. As the material contrast intensifies to $\sigma = 10^{-3}$, $\text{Cond}(\hat{J})$ increases from $3.93 \times 10^5$ to $3.10 \times 10^7$. Restricting the asymmetry to the $\mathcal{O}(10^{-13})$ to $\mathcal{O}(10^{-14})$ band demonstrates that the algebraic purification targets the restoration of cross-diagonal symmetry rather than simple scalar scaling. For the interval $\sigma \le 10^{-1}$, the $L_2$ and maximum errors converge to the $\mathcal{O}(10^{-14})$ band. This result confirms that the proposed topological mapping and algebraic projection algebraically cancel the discrete commutator errors at the FVM interface.

##### 4.1.3. Asymmetry control ($f$)

<br>

<small>Table 3: Algebraic and numerical integrity metrics as a function of the wave frequency $f$, demonstrating the exponential growth of the stabilization factor under severe geometric tension under control parameters of $N=256$ and $\sigma=10^{-2}$.</small>
| $f$ | $L_2$ Error | Max Error | Raw Asymmetry | Treated Asym | Cond($\hat{G}\hat{J}$) | Cond($\hat{C}\hat{G}\hat{J}$) | Stabilization |
|---|---|---|---|---|---|---|---|
| 1.0 | 2.6590E-14 | 5.7926E-14 | 2.1126E+02 | 5.6843E-14 | 3.2104E+06 | 2.4886E+06 | 1.3 x |
| 5.0 | 1.8283E-10 | 7.6680E-10 | 3.8471E+01 | 8.7311E-11 | 8.8909E+08 | 2.3659E+07 | 37.6 x |
| 10.0 | 9.1049E-09 | 4.4365E-08 | 1.1635E+01 | 2.3283E-10 | 5.0183E+09 | 4.0027E+07 | 125.4 x |
| 20.0 | 1.7316E-06 | 1.4969E-05 | 2.4254E+00 | 1.6298E-09 | 3.2588E+10 | 8.1369E+07 | 400.5 x |

<br>

The third scenario analyzes the geometric-algebraic interaction while scaling the wave frequency $f$ from 1.0 to 20.0 under the fixed conditions of $N=256$ and $\sigma=10^{-2}$, as presented in Table 3. As the wave frequency $f$ increases, the state variable curvature increases, elevating the local gradient required for spatial derivative evaluation during discretization. Consequently, the raw asymmetry indicator decreases as the frequency increases. This occurs because the second-order elliptic differential operator numerically dominates the first-order advection operator within the high-frequency band. Despite the decrease in asymmetry, $\text{Cond}(\hat{J})$ increases to $3.25 \times 10^{10}$ at $f=20.0$. This results from the expanded grid interval deviation as the r-adaptive topological mapping locally concentrates node coordinates in response to the error gradient. Applying the algebraic purification suppresses Cond($\hat{C}\hat{G}\hat{J}$) to $8.13 \times 10^7$, yielding a stabilization ratio of 400.5. This stabilization confirms that even under severe topological deformation, the eigenvalues of the preconditioned operator remain bounded within the complex disk $|\lambda - 1| \le \gamma_{int}$, as analytically proven in Appendix B.

#### 4.2. 2D singular perturbation system

Extending the one-dimensional verification, the proposed algebraic purification is verified on a two-dimensional unstructured triangular mesh featuring high geometric degrees of freedom, accompanied by a cross-derivative term along the area vector direction. The nonlinear elliptic PDE defined on the two-dimensional domain $\Omega = [0, 1] \times [0, 1]$ is expressed as follows:

$$
\nabla \cdot \left( p(u, x, y) \nabla u \right) = q(x, y) \quad \text{in } \Omega
\quad\text{(34)}
$$

To algebraically induce non-normality, an exponential nonlinear diffusion coefficient $p(u, x, y)$ is introduced, where $k_{nl}$ denotes the nonlinear strength. The spatial domain is divided into a left medium and a right medium at the vertical interface $x_{int} = 0.7$. A diffusion contrast coefficient $\sigma$ is applied to the right medium, formulating the local diffusion coefficient as follows:

$$
p(u, x, y) = 
\begin{cases} 
\exp(k_{nl} u) & \text{if } x \le x_{int} \\
\sigma \exp(k_{nl} u) & \text{if } x > x_{int} 
\end{cases}
\quad\text{(35)}
$$

The following 2D exponential decay model was applied as the analytical exact solution for MMS:

$$
u_{exact}(x, y) = 
\begin{cases} 
u_0 \exp(-\alpha_L x) \cos(\pi y) & \text{if } x \le x_{int} \\
u_0 \exp(-\alpha_L x_{int}) \exp(-\alpha_R (x - x_{int})) \cos(\pi y) & \text{if } x > x_{int} 
\end{cases}
\quad\text{(36)}
$$

Given a reference amplitude $u_0 = 1.0$ and a left medium decay rate $\alpha_L = 2.0$, the right medium decay rate $\alpha_R$ is determined via the nonlinear flux conservation law $p_L \nabla u_L \cdot \mathbf{n} = p_R \nabla u_R \cdot \mathbf{n}$ at the interface. As the exponential nonlinear term cancels out via the continuity condition $u_L = u_R$, the right decay rate derives as $\alpha_R = \alpha_L / \sigma$, inversely proportional to the diffusion contrast. An asymmetric Robin mixed boundary condition, specifying $\alpha=2.0$ and $\beta=1.0$, is imposed on the right and top boundaries to diffuse the cross-coupling asymmetry throughout the system.

In this two-dimensional verification, recursive Quadtree h-refinement is applied by detecting elements containing the physical interface $x_{int}=0.7$ and the outer boundary surface within the orthogonal initial grid network. This refinement divides the interface-containing elements into four sub-elements, proceeding to a depth of three levels. This subdivides the one-dimensional edge length of adjacent elements to $1/8$ and the two-dimensional area to $1/64$ of their initial values. Consequently, geometric resolution near the interface is secured, assembling an unstructured triangular network without hanging nodes via Delaunay simplex conversion. Consistent with the established limit conditions, topological mapping is applied to snap non-conforming nodes located within 50% of the local edge length to the interface coordinates. During this process, the area determinant of the triangular elements is inspected. Node movements causing element inversion or negative areas are rejected, preserving the geometric regularity of the Delaunay triangular network.

#### 4.2.1. Asymptotic convergence ($N$)

<br>

<div style="display: flex; justify-content: space-between; gap: 10px; text-align: center;">
<div style="width: 48%;">
<img src="FIG3a.png" style="width: 100%; height: auto;">
<div style="margin-top: 5px;">(a) $N=16$</div>
</div>
<div style="width: 48%;">
<img src="FIG3b.png" style="width: 100%; height: auto;">
<div style="margin-top: 5px;">(b) $N=32$</div>
</div>
</div>
<small>Fig. 3. Computed numerical solution surface and spatial scatter of absolute error for spatial resolutions $N=16$ and $N=32$. The top row displays the potential distribution $u(x,y)$ obtained via the finite volume simulation, while the bottom row illustrates the 3D scatter plot of the truncation error $|u_{exact} - u|$ in logarithmic scale, highlighting error localization near the diffusion discontinuity.</small>

<br><br>

<div style="display: flex; justify-content: space-between; gap: 10px; text-align: center;">
<div style="width: 48%;">
<img src="FIG4a.png" style="width: 100%; height: auto;">
<div style="margin-top: 5px;">(a) $N=16$</div>
</div>
<div style="width: 48%;">
<img src="FIG4b.png" style="width: 100%; height: auto;">
<div style="margin-top: 5px;">(b) $N=32$</div>
</div>
</div>
<small>Fig. 4. Local magnifications within the domain $x \in [0.65, 0.75]$ and $y \in [0, 0.1]$ of the mesh topology near the physical interface $x=0.7$, indicated by a red solid line. The top row depicts the non-conforming pristine mesh refined via successive spatial subdivisions. The bottom row demonstrates the conforming mesh post auto-snapping, aligning the element edges with the discontinuity to suppress the discrete commutator error.</small>

<br><br>

<small>Table 4: 2D algebraic asymptotic convergence and purification metrics across increasing spatial resolutions $N$ under control parameters of $\sigma=10^{-2}$ and $k_{nl}=2.0$.</small>
| $N$ | Total Nodes | $L_2$ Error | Max Error | Raw Asymmetry | Treated Asym | Cond($\hat{G}\hat{J}$) | Cond($\hat{C}\hat{G}\hat{J}$) | Stabilization |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 8 | 434 | 6.2213E-02 | 1.7897E-01 | 5.3920E+01 | 5.2832E-02 | 1.5954E+05 | 1.9227E+04 | 8.3 x |
| 16 | 1106 | 1.7367E-02 | 8.2148E-02 | 8.6057E+01 | 8.4176E-03 | 2.3528E+05 | 3.7610E+04 | 6.3 x |
| 32 | 2834 | 5.0272E-03 | 2.3894E-02 | 7.0629E+01 | 1.9342E-03 | 7.5444E+05 | 1.1679E+05 | 6.5 x |
| 64 | 7826 | 2.5668E-03 | 1.0892E-02 | 6.4419E+02 | 2.8159E-02 | 2.6779E+08 | 5.3757E+07 | 5.0 x |

<br>

The initial scenario expands the base one-dimensional spatial resolution $N$, applied equally to both the $x$ and $y$ directions, from 8 to 64 under controlled conditions of $\sigma=10^{-2}$ and $k_{nl}=2.0$, analyzing the discretization limit within the non-conforming grid system and the asymptotic convergence of the algebraic purification.

The analytical exact solution surface and the 3D scatter plot of the absolute error are evaluated under the basic spatial resolution conditions of $N=16$ and $N=32$, as depicted in Fig. 3. The absolute error is localized near the interface $x=0.7$ where the diffusion contrast is assigned. Increasing the spatial resolution from $N=16$ to $N=32$ induces a convergence behavior. The global $L_2$ error norm decreases from the $\mathcal{O}(10^{-2})$ band to the $\mathcal{O}(10^{-3})$ band.

The geometric topological change near $x_{int} = 0.7$ is illustrated in Fig. 4. The upper grid network maintains an orthogonal shape with increased node density due to spatial refinement. It remains in a non-conforming state, as the material boundary, indicated by a red solid line, intersects the triangular elements. In contrast, the lower schematic displays the final grid network. The vertical node row originally located closest to the interface in the upper orthogonal structure is mapped to the $x_{int} = 0.7$ line. The left and right triangular elements sharing the interface stretch and shrink proportionally with the node displacement without shape distortion or topological inversion, thereby preserving geometric regularity.

The changes in the system algebraic indicators corresponding to the resolution expansion $N$ under this topological mapping are quantitatively presented in Table 4. At $N=64$, the raw asymmetry indicator measures $6.44 \times 10^2$, and $\text{Cond}(\hat{J})$ scales to $2.67 \times 10^8$. Applying the indicator-driven purification detailed in Section 3 separates and subtracts the cross-coupling components, reducing the asymmetry to $2.81 \times 10^{-2}$. The $L_2$ error norm of the preconditioned system drops to $2.56 \times 10^{-3}$, maintaining asymptotic convergence.

#### 4.2.2. Algebraic robustness ($\sigma$)

<br>

<small>Table 5: Algebraic condition number stabilization and error statistics under varying diffusion contrast $\sigma$ under control parameters of $k_{nl}=1.0$ and $N=32$.</small>
| $\sigma$ | $L_2$ Error | Max Error | Raw Asymmetry | Treated Asym | Cond($\hat{G}\hat{J}$) | Cond($\hat{C}\hat{G}\hat{J}$) | Stabilization |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 1.00E+00 | 5.5767E-04 | 1.1162E-02 | 8.6578E+00 | 9.9182E-05 | 2.3282E+04 | 9.5227E+03 | 2.4 x |
| 1.00E-01 | 2.1215E-03 | 1.1090E-02 | 4.7600E+01 | 8.3343E-03 | 6.4476E+06 | 2.4953E+06 | 2.6 x |
| 1.00E-02 | 5.0586E-03 | 2.0978E-02 | 1.0521E+01 | 4.7938E-04 | 8.9129E+04 | 3.5703E+04 | 2.5 x |
| 1.00E-03 | 8.9624E-02 | 3.6077E-01 | 1.0973E+01 | 2.0716E-04 | 1.0274E+06 | 3.3225E+05 | 3.1 x |

<br>

The second scenario gradually reduces $\sigma$ from 1.0 to $10^{-3}$ under the condition of $k_{nl}=1.0$ and $N=32$ as presented in Table 5. This experiment analyzes the geometric topological deformation and the algebraic stability of the system induced when the differential discontinuity of the interface exceeds the limit of the geometric resolution of the grid.

At $\sigma=10^{-3}$, the right medium exponential decay rate increases to $\alpha_R=2000$ via the interface flux conservation relation $\alpha_R = \alpha_L / \sigma$, inducing a pronounced differential discontinuity, or kink, at the interface. Consequently, the exponential decay concentrates within a highly localized region at $x_{int} = 0.7$, amplifying the truncation error of the discretization system. While the r-adaptive topological mapping concentrates grid points at the interface to resolve the gradient, a sub-grid resolution shortage occurs, failing to track the true physical solution due to the fixed total node count.

As $\sigma$ decreases, $\text{Cond}(\hat{J})$ increases from $2.32 \times 10^4$ to $1.02 \times 10^6$, and the $L_2$ error norm rises to $8.96 \times 10^{-2}$. Even under this numerical resolution shortage, the proposed algebraic purification suppresses the numerical divergence of the nonlinear solution. The asymmetry of $\hat{C}\hat{G}\hat{J}$ remains restricted to $2.07 \times 10^{-4}$. This results from projecting the irrotational asymmetric potential field, extracted via the DHHD, onto the diagonal scaling matrix $\hat{C}$, algebraically canceling the magnitude imbalance between the cross-diagonal components within the Jacobian.

##### 4.2.3. Asymmetry control ($k_{nl}$)

<br>

<small>Table 6: Degradation of raw matrix asymmetry and subsequent stabilization via algebraic purification under varying nonlinear strength $k_{nl}$ under control parameters of $\sigma=10^{-1}$ and $N=32$.</small>
| $k_{nl}$ | $L_2$ Error | Max Error | Raw Asymmetry | Treated Asym | Cond($\hat{G}\hat{J}$) | Cond($\hat{C}\hat{G}\hat{J}$) | Stabilization |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 0.0 | 1.7916E-03 | 1.1231E-02 | 1.5343E+00 | 0.0000E+00 | 6.3622E+03 | 6.3622E+03 | 1.0 x |
| 1.0 | 2.0420E-03 | 1.1119E-02 | 8.6497E+00 | 9.8184E-05 | 3.1746E+04 | 1.4703E+04 | 2.2 x |
| 2.0 | 2.1919E-03 | 1.0989E-02 | 6.2066E+01 | 2.5039E-03 | 2.9539E+05 | 3.2127E+04 | 9.2 x |
| 4.0 | 2.5769E-03 | 1.0629E-02 | 3.3062E+03 | 6.2804E-01 | 2.2938E+08 | 2.3674E+05 | 968.9 x |

<br>

The final scenario analyzes the effect of the Fréchet derivative asymmetry on the algebraic structure and convergence characteristics while varying $k_{nl}$ from 0.0 to 4.0, under fixed conditions of $N=32$ and $\sigma=10^{-1}$, as presented in Table 6. As $k_{nl}$ increases, $L_1$ within $\hat{J}$ becomes dominant, elevating the system non-normality.

For the linear system at $k_{nl} = 0.0$, the raw asymmetry indicator measures 1.53. Because the residual of the advection operator $L_1$, defined in Section 2.1, vanishes in this linear regime, the raw Jacobian inherently lacks the irrotational anti-symmetric potential field. Consequently, the algebraic projection extracts a null vector, rendering the preconditioned matrix algebraically equivalent to the raw system. As $k_{nl}$ increases to 4.0, the imbalance between the cross-diagonal components of the Jacobian expands, raising the raw asymmetry to $3.30 \times 10^3$. This increased non-normality induces non-orthogonality in the eigenvector basis and causes transient perturbation growth during the Newton iteration process, reducing the convergence speed. Under the strong nonlinear condition $k_{nl} = 4.0$, $\text{Cond}(\hat{G}\hat{J})$ reaches $2.29 \times 10^8$, increasing the algebraic ill-conditioning. The proposed algebraic purification isolates and subtracts the asymmetric potential field within the Jacobian, suppressing $\text{Cond}(\hat{C}\hat{G}\hat{J})$ to $2.36 \times 10^5$. The resulting stabilization ratio of 968.9 demonstrates that the control efficiency of the algebraic purification increases as the nonlinearity strengthens.

---

### 5. Conclusion and future works

This study identifies the algebraic origin of the Jacobian operator non-normality and the discrete commutator error arising during the discretization of nonlinear PDEs. A numerical procedure is established to control these errors through algebraic purification. Introducing the residue transformation $\mathcal{R}(L) \equiv L - L^\dagger$ of a linear operator, the first-order advection operator within the Fréchet derivative is defined as the effective drift velocity. Weak-form expansion demonstrates that the system asymmetry originates from the combination of the effective drift velocity divergence $Dv$ and the homogeneous advection $2vD$. These components are algebraically isolated. Mapping the isolated continuous advection residual to the discrete space derives a local indicator based on the discrete commutator error. Projecting this local indicator onto a weighted Graph Laplacian system establishes an r-adaptive topological mapping responding to the error gradient to control mesh tangling and geometrically isolate numerical singularities.

A global indicator is extracted from the cross-diagonal preservation constraint of the effective Jacobian to construct an algebraic preconditioner. This global indicator is analytically equivalent to the sum of the geometric volume ratio in the FVM space and the one-dimensional line integral of the Péclet field. Applying the discrete Helmholtz-Hodge decomposition (DHHD) to the global indicator compresses the physical asymmetry into a symmetric scalar potential space. Instead of the unjustified removal of asymmetric convective terms, the procedure algebraically isolates and subtracts only the incompressible, purely rotational anti-symmetric residues. This precise subtraction completes the final purification, preconditioning the effective Jacobian and symmetrizing the search matrix for the linear solver while restoring the structural health of the discrete operator. Verified via the MMS, the proposed indicator-driven purification demonstrates condition number stabilization. Controlling the residual asymmetry within the machine precision limit ensures the spectral integrity of the system. This confirms the theoretical asymptotic quadratic convergence $\mathcal{O}(\Delta x^2)$ without the addition of artificial numerical viscosity.

The residue transformation and algebraic purification established here derive from the vanishing condition $\mathcal{R}(J) = 0$ inside the strongly elliptic conservation system. Based on this structural analysis of operators, future work extends this numerical procedure to more complex PDE systems. For purely advection-dominated systems on fixed highly non-uniform meshes where geometric control is restricted, an orthogonal decomposition is required to separate the physical anti-symmetric components in continuous space from the numerical truncation errors. This separation provides an algebraic basis for a structure-preserving spatial discretization that selectively controls numerical errors while preserving physical fluxes. Additionally, extensions to energy-conserving systems, such as pure hyperbolic wave equations lacking diffusion terms, are considered. In this context, deriving quantitative diagnostic indicators for numerical dissipation and dispersion during time integration, based on the discrete commutator error, serves as a criterion to evaluate the physical conservation of high-order wave equation discretization schemes. Finally, beyond steady-state systems, further research on algebraic purification for spatio-temporal Jacobian systems utilizing fully implicit time integration is required. Designing a spatio-temporal preconditioner that suppresses the eigenvalue drift of nonlinear systems due to time-step variations and ensures algebraic stability contributes to the analysis of complex multiphysics systems.

---

### Appendix A. Graph Laplacian and discrete Helmholtz-Hodge decomposition

The normal equation is formulated to determine the least-squares solution $\mathbf{Z}_{LS}$ minimizing the objective function of the overdetermined linear system $\hat{S}\mathbf{Z} = \mathbf{b}$:

$$
(\hat{S}^T \hat{S}) \mathbf{Z}_{LS} = \hat{S}^T \mathbf{b}
\quad\text{(A.1)}
$$

In this context, $\hat{S}$ acts as a discrete gradient operator mapping node potentials to edges, while $\hat{S}^T$ functions as a discrete divergence operator retrieving edge data back to nodes. Consequently, the operator $(\hat{S}^T \hat{S})$ represents the unweighted Graph Laplacian, solely determined by the mesh topology. Based on the DHHD, an arbitrary edge vector $\mathbf{b}$ decomposes into two mutually orthogonal components [38, 39, 40, 41]:

$$
\mathbf{b} = \hat{S} \mathbf{Z}_{LS} + \mathbf{r}
\quad\text{(A.2)}
$$

The projected component $\hat{S} \mathbf{Z}_{LS}$ represents the conservative, irrotational asymmetry. Within the framework of algebraic purification, this component is isolated and projected into the symmetric scalar potential space to formulate the symmetric preconditioner $\hat{C}$. Conversely, the residual $\mathbf{r}$ belongs to the left null space of $\hat{S}$ ($\hat{S}^T \mathbf{r} = \mathbf{0}$). It represents the solenoidal, purely rotational asymmetry, which is the specific component that cannot be projected into the symmetric scalar potential space.

Given the orthogonality of the two vectors, the Pythagorean theorem yields $\| \mathbf{b} \|_2^2 = \| \hat{S}\mathbf{Z}_{LS} \|_2^2 + \| \mathbf{r} \|_2^2$. This relation derives the cancellation ratio $\eta$, quantifying the resolution of the conservative asymmetric components within the system:

$$
\eta = \frac{\|\hat{S}\mathbf{Z}_{LS}\|_2^2}{\|\mathbf{b}\|_2^2} = 1 - \frac{\|\mathbf{r}\|_2^2}{\|\mathbf{b}\|_2^2}
\quad\text{(A.3)}
$$

---

### Appendix B. Spectral bound and convergence proof of the preconditioned operator

The eigenvalue of the target operator $\tilde{J}_{pure}^{-1} \tilde{J}$ is defined as $\lambda \in \mathbb{C}$, with the corresponding eigenvector $\mathbf{w} \in \mathbb{C}^n$. Based on Eq. (30), $\tilde{J}$ is expressed as $\tilde{J} = \tilde{J}_{pure} + \tilde{A}_{int}$. Substituting this relation into the generalized eigenvalue problem $\tilde{J} \mathbf{w} = \lambda \tilde{J}_{pure} \mathbf{w}$ and subtracting $\tilde{J}_{pure} \mathbf{w}$ from both sides isolates $\tilde{A}_{int}$:

$$
\tilde{A}_{int} \mathbf{w} = (\lambda - 1) \tilde{J}_{pure} \mathbf{w}
\quad\text{(B.1)}
$$

Pre-multiplying both sides by the conjugate transpose of the eigenvector $\mathbf{w}^*$ constructs a quadratic form. At this stage, $\tilde{J}_{pure}$ decomposes into a symmetric component $\tilde{H}$ and a boundary anti-symmetric component $\tilde{A}_{bnd}$, expressed as $\tilde{J}_{pure} = \tilde{H} + \tilde{A}_{bnd}$. Substituting this decomposition into the right-hand side separates the components:

$$
\mathbf{w}^* \tilde{A}_{int} \mathbf{w} = (\lambda - 1) \big( \mathbf{w}^* \tilde{H} \mathbf{w} + \mathbf{w}^* \tilde{A}_{bnd} \mathbf{w} \big)
\quad\text{(B.2)}
$$

Under the normalization condition $\|\mathbf{w}\| = 1$, the positive definite property ensures the symmetric form is a real scalar $\mathbf{w}^* \tilde{H} \mathbf{w} = h > 0$. The anti-symmetry dictates that the corresponding quadratic forms are purely imaginary, defined as $\mathbf{w}^*\tilde{A}_{int} \mathbf{w} = i\mu$ and $\mathbf{w}^*\tilde{A}_{bnd} \mathbf{w} = i\nu$ for real numbers $\mu, \nu \in \mathbb{R}$. Substituting these scalar variables yields the implicit relation $i\mu = (\lambda - 1)(h + i\nu)$. Taking the squared modulus of both sides derives the squared magnitude of the eigenvalue center shift:

$$
|\lambda - 1|^2 = \frac{\mu^2}{h^2 + \nu^2}
\quad\text{(B.3)}
$$

Since $\nu^2 \ge 0$ in the denominator, the upper bound for the specific eigenvector $\mathbf{w}$ is established, which is globally bounded by the supremum over all non-zero vectors:

$$
|\lambda - 1| \le \frac{|\mu|}{h} = \frac{|\mathbf{w}^* \tilde{A}_{int} \mathbf{w}|}{\mathbf{w}^* \tilde{H} \mathbf{w}} \le \sup_{\mathbf{w} \ne 0} \left\{ \frac{|\mathbf{w}^* \tilde{A}_{int} \mathbf{w}|}{\mathbf{w}^* \tilde{H} \mathbf{w}} \right\} \equiv \gamma_{int}
\quad\text{(B.4)}
$$

Here, $\gamma_{int}$ defines the relative continuity constant of $\tilde{A}_{int}$ with respect to $\tilde{H}$. Therefore, the spectrum $\Lambda(\tilde{J}_{pure}^{-1} \tilde{J})$ is bounded within the following complex disk:

$$
\Lambda(\tilde{J}_{pure}^{-1} \tilde{J}) \subset \{ \lambda \in \mathbb{C} : |\lambda - 1| \le \gamma_{int} \}
\quad\text{(B.5)}
$$

This indicates that the proposed algebraic purification clusters the eigenvalue distribution of the target operator within a bounded disk on the complex plane, guaranteeing the linear convergence of the Krylov solver [42].

---

### References

[1] Wright, T. G., & Trefethen, L. N. (2002). Pseudospectra of rectangular matrices. IMA Journal of Numerical Analysis, 22(4), 501-519. https://doi.org/10.1093/imanum/22.4.501 <br>
[2] Trefethen, L. N., & Embree, M. (2020). Spectra and pseudospectra: the behavior of nonnormal matrices and operators. Princeton University Press. <br>
[3] Schmid, P. J. (2007). Nonmodal stability theory. Annual Review of Fluid Mechanics, 39, 129-162. https://doi.org/10.1146/annurev.fluid.38.050304.092139 <br>
[4] Trefethen, L. N. (1997). Pseudospectra of linear operators. SIAM Review, 39(3), 383-406. https://doi.org/10.1137/S0036144595295284 <br>
[5] Saad, Y., & Schultz, M. H. (1986). GMRES: A generalized minimal residual algorithm for solving nonsymmetric linear systems. SIAM Journal on Scientific and Statistical Computing, 7(3), 856-869. https://doi.org/10.1137/0907058 <br>
[6] Liesen, J., & Strakos, Z. (2013). Krylov subspace methods: principles and analysis. Numerical Mathematics and Scie. Oxford University Press. <br>
[7] Cai, X. C., & Keyes, D. E. (2002). Nonlinearly preconditioned inexact Newton algorithms. SIAM Journal on Scientific Computing, 24(1), 183-200. https://doi.org/10.1137/S106482750037620X <br>
[8] Winslow, A. M. (1997). Numerical solution of the quasilinear Poisson equation in a nonuniform triangle mesh. Journal of Computational Physics, 135(2), 128-138. https://doi.org/10.1006/jcph.1997.5698 <br>
[9] Dvinsky, A. S. (1991). Adaptive grid generation from harmonic maps on Riemannian manifolds. Journal of Computational Physics, 95(2), 450-476. https://doi.org/10.1016/0021-9991(91)90285-S <br>
[10] Budd, C. J., Huang, W., & Russell, R. D. (2009). Adaptivity with moving grids. Acta Numerica, 18, 111-241. https://doi.org/10.1017/S0962492906400015 <br>
[11] Tang, T. (2005). Moving mesh methods for computational fluid dynamics. Contemporary mathematics, 383(8), 141-173. https://doi.org/10.1090/conm/383/07162 <br>
[12] Shewchuk, J. R. (2002). Delaunay refinement algorithms for triangular mesh generation. Computational Geometry, 22(1-3), 21-74. https://doi.org/10.1016/S0925-7721(01)00047-5 <br>
[13] Bhatia, H., Norgard, G., Pascucci, V., & Bremer, P.-T. (2012). The Helmholtz-Hodge decomposition—A survey. IEEE Transactions on Visualization and Computer Graphics, 19(8), 1386-1404. https://doi.org/10.1109/TVCG.2012.316 <br>
[14] Roache, P. J. (2002). Code verification by the method of manufactured solutions. J. Fluids Eng., 124(1), 4-10. https://doi.org/10.1115/1.1436090 <br>
[15] Roy, C. J., Smith, T. M., & Ober, C. C. (2002). Verification of a compressible CFD code using the method of manufactured solutions. AIAA Paper 2002-3110. https://doi.org/10.2514/6.2002-3110 <br>
[16] Shunn, L., Ham, F., & Moin, P. (2012). Verification of variable-density flow solvers using manufactured solutions. Journal of Computational Physics, 231, 3801-3827. https://doi.org/10.1016/j.jcp.2012.01.027 <br>
[17] Hyman, J. M., & Shashkov, M. (1997). Natural discretizations for the divergence, gradient, and curl on logically rectangular grids. Computers & Mathematics with Applications, 33(4), 81-104. https://doi.org/10.1016/S0898-1221(97)00009-6 <br>
[18] Hyman, J. M., & Shashkov, M. (1999). The orthogonal decomposition theorems for mimetic finite difference methods. SIAM Journal on Numerical Analysis, 36(3), 788-818. https://doi.org/10.1137/S0036142996314044 <br>
[19] Mattsson, K., & Nordström, J. (2004). Summation by parts operators for finite difference approximations of second derivatives. Journal of Computational Physics, 199(2), 503-540. https://doi.org/10.1016/j.jcp.2004.03.001 <br>
[20] Lipnikov, K., Manzini, G., & Shashkov, M. (2014). Mimetic finite difference method. Journal of Computational Physics, 257, 1163-1227. https://doi.org/10.1016/j.jcp.2013.07.031 <br>
[21] Knoll, D. A., & Keyes, D. E. (2004). Jacobian-free Newton–Krylov methods: a survey of approaches and applications. Journal of Computational Physics, 193(2), 357-397. https://doi.org/10.1016/j.jcp.2003.08.010 <br>
[22] Pernice, M., & Walker, H. F. (1998). NITSOL: A Newton iterative solver for nonlinear systems. SIAM Journal on Scientific Computing, 19(1), 302-318. https://doi.org/10.1137/S1064827596303843 <br>
[23] Brown, P. N., & Saad, Y. (1990). Hybrid Krylov methods for nonlinear systems of equations. SIAM Journal on Scientific and Statistical Computing, 11(3), 450-481. https://doi.org/10.1137/0911026 <br>
[24] LeVeque, R. J. (2002). Finite volume methods for hyperbolic problems (Vol. 31). Cambridge university press. <br>
[25] Banks, J. W., Aslam, T. D., & Rider, W. J. (2008). On sub-linear convergence for linearly degenerate waves in capturing schemes. Journal of Computational Physics, 227(14), 6985-7002. https://doi.org/10.1016/j.jcp.2008.04.002 <br>
[26] Huang, W., & Russell, R. D. (2011). Adaptive Moving Mesh Methods. Springer. https://doi.org/10.1007/978-1-4419-7916-2 <br>
[27] Eymard, R., Gallouët, T., & Herbin, R. (2000). Finite volume methods. Handbook of numerical analysis, 7, 713-1018. https://doi.org/10.1016/S1570-8659(00)07005-8 <br>
[28] Dembo, R. S., Eisenstat, S. C., & Steihaug, T. (1982). Inexact newton methods. SIAM Journal on Numerical analysis, 19(2), 400-408. https://doi.org/10.1137/0719025 <br>
[29] Eisenstat, S. C., & Walker, H. F. (1996). Choosing the forcing terms in an inexact Newton method. SIAM Journal on Scientific Computing, 17(1), 16-32. https://doi.org/10.1137/0917003 <br>
[30] Roy, C. J., Raju, A., & Hopkins, M. M. (2007). Estimation of discretization errors using the method of nearby problems. AIAA journal, 45(6), 1232-1243. https://doi.org/10.2514/1.24282 <br>
[31] Grier, B., Figliola, R., Alyanak, E., & Camberos, J. (2015). Discontinuous solutions using the method of manufactured solutions on finite volume solvers. AIAA Journal, 53(8), 2369-2378. https://doi.org/10.2514/1.J053725 <br>
[32] Blais, B., & Bertrand, F. (2015). On the use of the method of manufactured solutions for the verification of CFD codes for the volume-averaged Navier–Stokes equations. Computers & fluids, 114, 121-129. https://doi.org/10.1016/j.compfluid.2015.03.002 <br>
[33] Powers, J. M., & Aslam, T. D. (2006). Exact solution for multidimensional compressible reactive flow for verifying numerical algorithms. AIAA Journal, 44(2), 337-344. https://doi.org/10.2514/1.14404 <br>
[34] Bond, R. B., Ober, C. C., Knupp, P. M., & Bova, S. W. (2007). Manufactured solution for computational fluid dynamics boundary condition verification. AIAA journal, 45(9), 2224-2236. https://doi.org/10.2514/1.28099 <br>
[35] Brady, P. T., Herrmann, M., & Lopez, J. M. (2012). Code verification for finite volume multiphase scalar equations using the method of manufactured solutions. Journal of Computational Physics, 231(7), 2924-2944. https://doi.org/10.1016/j.jcp.2011.12.040 <br>
[36] Knupp, P. M. (2001). Algebraic mesh quality metrics. SIAM journal on scientific computing, 23(1), 193-218. https://doi.org/10.1137/S1064827500371499 <br>
[37] Li, R., Tang, T., & Zhang, P. (2001). Moving mesh methods in multiple dimensions based on harmonic maps. Journal of Computational Physics, 170(2), 562-588. https://doi.org/10.1006/jcph.2001.6749 <br>
[38] Ahusborde, E., Azaïez, M., & Caltagirone, J. P. (2007). A primal formulation for the Helmholtz decomposition. Journal of Computational Physics, 225(1), 13-19. https://doi.org/10.1016/j.jcp.2007.04.002 <br>
[39] Lemoine, A., Caltagirone, J. P., Azaïez, M., & Vincent, S. (2015). Discrete Helmholtz-Hodge decomposition on polyhedral meshes using compatible discrete operators. Journal of Scientific Computing, 65(1), 34-53. https://doi.org/10.1007/s10915-014-9952-8 <br>
[40] Polthier, K., & Preuß, E. (2003). Identifying vector field singularities using a discrete Hodge decomposition. In Mathematical Visualization III (pp. 112-134). Springer. <br>
[41] Angot, P., Caltagirone, J. P., & Fabrie, P. (2013). Fast discrete Helmholtz-Hodge decompositions in bounded domains. Applied Mathematics Letters, 26(4), 445-451. https://doi.org/10.1016/j.aml.2012.11.006 <br>
[42] Saad, Y. (2003). Iterative Methods for Sparse Linear Systems (2nd ed.). SIAM. <br>